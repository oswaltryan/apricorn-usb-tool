from usb_tool.cross_usb import runtime_check
if __name__ == "__main__":
    runtime_check()